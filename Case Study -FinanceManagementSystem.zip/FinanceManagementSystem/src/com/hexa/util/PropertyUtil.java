package com.hexa.util;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class PropertyUtil {
    public static String getPropertyString() throws IOException {
        Properties props = new Properties();
        try (FileReader reader = new FileReader("src/hexadb.properties")) {
            props.load(reader);
        }

        String host = props.getProperty("hostname");
        String port = props.getProperty("port");
        String db = props.getProperty("dbname");
        String user = props.getProperty("username");
        String pwd = props.getProperty("password");

        return "jdbc:mysql://" + host + ":" + port + "/" + db + "?user=" + user + "&password=" + pwd;
    }

    public static String getDriverClassName() throws IOException {
        Properties props = new Properties();
        try (FileReader reader = new FileReader("src/hexadb.properties")) {
            props.load(reader);
        }
        return props.getProperty("driver");
    }
}
