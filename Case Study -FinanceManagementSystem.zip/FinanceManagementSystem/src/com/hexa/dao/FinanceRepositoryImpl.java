package com.hexa.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.hexa.entity.User;
import com.hexa.entity.Expense;
import com.hexa.exception.UserNotFoundException;
import com.hexa.exception.ExpenseNotFoundException;
import com.hexa.util.DBConnection;

public class FinanceRepositoryImpl implements IFinanceRepository {

    @Override
    public boolean createUser(User user) {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "INSERT INTO user (userId, name, email) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, user.getUserId());
            stmt.setString(2, user.getName());
            stmt.setString(3, user.getEmail());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error creating user: " + e.getMessage());
            return false;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    @Override
    public boolean createExpense(Expense expense) {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "INSERT INTO expense (expenseId, userId, category, amount, date) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, expense.getExpenseId());
            stmt.setInt(2, expense.getUserId());
            stmt.setString(3, expense.getCategory());
            stmt.setDouble(4, expense.getAmount());
            stmt.setString(5, expense.getDate());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error creating expense: " + e.getMessage());
            return false;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    @Override
    public boolean deleteUser(int userId) {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "DELETE FROM user WHERE userId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting user: " + e.getMessage());
            return false;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    @Override
    public boolean deleteExpense(int expenseId) {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "DELETE FROM expense WHERE expenseId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, expenseId);
            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting expense: " + e.getMessage());
            return false;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    @Override
    public List<Expense> getAllExpenses(int userId) throws UserNotFoundException {
        List<Expense> list = new ArrayList<>();
        Connection conn = null;
        try {
            getUser1(userId); 
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM expense WHERE userId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Expense e = new Expense(
                    rs.getInt("expenseId"),
                    rs.getInt("userId"),
                    rs.getString("category"),
                    rs.getDouble("amount"),
                    rs.getString("date")
                );
                list.add(e);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving expenses: " + e.getMessage());
        } finally {
            DBConnection.closeConnection(conn);
        }
        return list;
    }

    @Override
    public boolean updateExpense(int userId, Expense expense) throws UserNotFoundException, ExpenseNotFoundException {
        Connection conn = null;
        try {
            getUser1(userId); 
            getExpense1(expense.getExpenseId()); 
            conn = DBConnection.getConnection();
            String sql = "UPDATE expense SET category = ?, amount = ?, date = ? WHERE userId = ? AND expenseId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, expense.getCategory());
            stmt.setDouble(2, expense.getAmount());
            stmt.setString(3, expense.getDate());
            stmt.setInt(4, userId);
            stmt.setInt(5, expense.getExpenseId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating expense: " + e.getMessage());
            return false;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
    @Override
    public User getUser1(int userId) throws UserNotFoundException {
        String query = "SELECT * FROM user WHERE userid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");
                String email = rs.getString("email");
                return new User(userId, name, email);
            } else {
                throw new UserNotFoundException("User with ID " + userId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new UserNotFoundException("Database error while fetching user.");
        }
    }


    public User getUser(int userId) throws UserNotFoundException {
        Connection conn = null;
        User user = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM user WHERE userId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                user = new User(
                    rs.getInt("userId"),
                    rs.getString("name"),
                    rs.getString("email")
                );
            } else {
                throw new UserNotFoundException("User not found for ID: " + userId);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving user: " + e.getMessage());
        } finally {
            DBConnection.closeConnection(conn);
        }
        return user;
    }
    
    @Override
    public Expense getExpense1(int expenseId) throws ExpenseNotFoundException {
        String query = "SELECT * FROM expense WHERE expenseid = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, expenseId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("userid");
                String category = rs.getString("category");
                double amount = rs.getDouble("amount");
                String date = rs.getString("date");
                return new Expense(expenseId, userId, category, amount, date);
            } else {
                throw new ExpenseNotFoundException("Expense with ID " + expenseId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ExpenseNotFoundException("Database error while fetching expense.");
        }
    }


    public Expense getExpense(int expenseId) throws ExpenseNotFoundException {
        Connection conn = null;
        Expense expense = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM expense WHERE expenseId = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, expenseId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                expense = new Expense(
                    rs.getInt("expenseId"),
                    rs.getInt("userId"),
                    rs.getString("category"),
                    rs.getDouble("amount"),
                    rs.getString("date")
                );
            } else {
                throw new ExpenseNotFoundException("Expense not found for ID: " + expenseId);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving expense: " + e.getMessage());
        } finally {
            DBConnection.closeConnection(conn);
        }
        return expense;
    }
}
