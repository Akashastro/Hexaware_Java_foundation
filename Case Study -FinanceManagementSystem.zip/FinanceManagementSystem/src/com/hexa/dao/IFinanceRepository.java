package com.hexa.dao;

import com.hexa.entity.*;
import com.hexa.exception.ExpenseNotFoundException;
import com.hexa.exception.UserNotFoundException;

import java.util.List;

public interface IFinanceRepository {
    boolean createUser(User user);
    boolean createExpense(Expense expense);
    boolean deleteUser(int userId);
    boolean deleteExpense(int expenseId);
    List<Expense> getAllExpenses(int userId) throws UserNotFoundException;
    boolean updateExpense(int userId, Expense expense) throws UserNotFoundException, ExpenseNotFoundException;
    User getUser(int userId) throws UserNotFoundException;
    Expense getExpense(int expenseId) throws ExpenseNotFoundException;
	User getUser1(int userId) throws UserNotFoundException;
	Expense getExpense1(int expenseId) throws ExpenseNotFoundException;
    
    
	
}
