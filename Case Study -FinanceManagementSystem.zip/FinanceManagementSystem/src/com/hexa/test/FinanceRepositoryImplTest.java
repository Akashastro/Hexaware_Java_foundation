package com.hexa.test;

import com.hexa.dao.FinanceRepositoryImpl;
import com.hexa.dao.IFinanceRepository;
import com.hexa.entity.Expense;
import com.hexa.entity.User;
import com.hexa.exception.ExpenseNotFoundException;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

class FinanceSystemTest {

    private static IFinanceRepository repository;

    @BeforeAll
    static void setup() {
        repository = new FinanceRepositoryImpl();
    }

    @Test
    void testUserCreationSuccess() {
        User user = new User(101, "Alice", "alice@example.com");
        boolean result = repository.createUser(user);
        assertTrue(result, "User should be created successfully");
    }

    @Test
    void testExpenseCreationSuccess() {
        Expense expense = new Expense(201, 101, "Food", 500.0, "2025-05-04");
        boolean result = repository.createExpense(expense);
        assertTrue(result, "Expense should be created successfully");
    }

    @Test
    void testGetExpenseSuccess() throws ExpenseNotFoundException {
        Expense expense = repository.getExpense(201);
        assertNotNull(expense, "Expense should be found");
        assertEquals(201, expense.getExpenseId(), "Expense ID should match");
    }

    @Test
    void testExpenseNotFoundExceptionThrown() {
        assertThrows(ExpenseNotFoundException.class, () -> {
            repository.getExpense(999); 
        });
    }
}
