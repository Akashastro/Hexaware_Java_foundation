package com.hexa.main;

import com.hexa.dao.FinanceRepositoryImpl;
import com.hexa.dao.IFinanceRepository;
import com.hexa.entity.User;
import com.hexa.entity.Expense;
import com.hexa.exception.UserNotFoundException;
import com.hexa.exception.ExpenseNotFoundException;

import java.util.Scanner;

public class FinanceApp {

    public static void main(String[] args) throws UserNotFoundException, ExpenseNotFoundException {
        Scanner scanner = new Scanner(System.in);
        IFinanceRepository repository = new FinanceRepositoryImpl();
        int choice;

        do {
            System.out.println("\n=== Finance Management Menu ===");
            System.out.println("1. Add User");
            System.out.println("2. Add Expense");
            System.out.println("3. Delete User");
            System.out.println("4. Delete Expense");
            System.out.println("5. Update Expense");
            System.out.println("6. View User and Expense by ID");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");

            while (!scanner.hasNextInt()) {
                System.out.print("Please enter a valid number: ");
                scanner.next();
            }
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    addUser(scanner, repository);
                    break;
                case 2:
                    addExpense(scanner, repository);
                    break;
                case 3:
                    deleteUser(scanner, repository);
                    break;
                case 4:
                    deleteExpense(scanner, repository);
                    break;
                case 5:
                    updateExpense(scanner, repository);
                    break;
                case 6:
                    viewUserAndExpenseById(scanner, repository);
                    break;
                case 7:
                    System.out.println("Exiting application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please select from the menu.");
            }
        } while (choice != 7);

        scanner.close();
    }

    private static void addUser(Scanner scanner, IFinanceRepository repository) {
        try {
            System.out.print("Enter User ID: ");
            int userId = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Email: ");
            String email = scanner.nextLine();

            User user = new User(userId, name, email);
            boolean success = repository.createUser(user);
            if (success) {
                System.out.println("User added successfully.");
            } else {
                System.out.println("Failed to add user.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. User ID must be a number.");
        }
    }

    private static void addExpense(Scanner scanner, IFinanceRepository repository) {
        try {
            System.out.print("Enter Expense ID: ");
            int expenseId = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter User ID: ");
            int userId = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter Category: ");
            String category = scanner.nextLine();
            System.out.print("Enter Amount: ");
            double amount = Double.parseDouble(scanner.nextLine());
            System.out.print("Enter Date (YYYY-MM-DD): ");
            String date = scanner.nextLine();

            Expense expense = new Expense(expenseId, userId, category, amount, date);
            boolean success = repository.createExpense(expense);
            if (success) {
                System.out.println("Expense added successfully.");
            } else {
                System.out.println("Failed to add expense.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter numeric values for IDs and amount.");
        }
    }

    private static void deleteUser(Scanner scanner, IFinanceRepository repository) {
        try {
            System.out.print("Enter User ID to delete: ");
            int userId = Integer.parseInt(scanner.nextLine());
            boolean success = repository.deleteUser(userId);
            if (success) {
                System.out.println("User deleted successfully.");
            } else {
                System.out.println("Failed to delete user. User may not exist.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. User ID must be a number.");
        }
    }

    private static void deleteExpense(Scanner scanner, IFinanceRepository repository) {
        try {
            System.out.print("Enter Expense ID to delete: ");
            int expenseId = Integer.parseInt(scanner.nextLine());
            boolean success = repository.deleteExpense(expenseId);
            if (success) {
                System.out.println("Expense deleted successfully.");
            } else {
                System.out.println("Failed to delete expense. Expense may not exist.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Expense ID must be a number.");
        }
    }

    private static void updateExpense(Scanner scanner, IFinanceRepository repository) throws UserNotFoundException, ExpenseNotFoundException {
        try {
            System.out.print("Enter User ID: ");
            int userId = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter Expense ID to update: ");
            int expenseId = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter New Category: ");
            String category = scanner.nextLine();
            System.out.print("Enter New Amount: ");
            double amount = Double.parseDouble(scanner.nextLine());
            System.out.print("Enter New Date (YYYY-MM-DD): ");
            String date = scanner.nextLine();

            Expense expense = new Expense(expenseId, userId, category, amount, date);
            boolean success = repository.updateExpense(userId, expense);
            if (success) {
                System.out.println("Expense updated successfully.");
            } else {
                System.out.println("Failed to update expense. Please check if the user and expense exist.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter numeric values for IDs and amount.");
        }
    }

    private static void viewUserAndExpenseById(Scanner scanner, IFinanceRepository repository) {
        try {
            System.out.print("Enter User ID to view: ");
            int userId = Integer.parseInt(scanner.nextLine());
            User user = repository.getUser(userId);
            System.out.println("User Found: " + user.getUserId() + " - " + user.getName() + " - " + user.getEmail());

            System.out.print("Enter Expense ID to view: ");
            int expenseId = Integer.parseInt(scanner.nextLine());
            Expense expense = repository.getExpense(expenseId);
            System.out.println("Expense Found: " + expense.getExpenseId() + " - " + expense.getCategory() + " - " +
                    expense.getAmount() + " - " + expense.getDate());

        } catch (NumberFormatException e) {
            System.out.println("Invalid input. IDs must be numeric.");
        } catch (UserNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (ExpenseNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
