package com.hexa.dao;

import java.util.List;
import com.hexa.entity.Appointment;
import com.hexa.myexceptions.PatientNumberNotFoundException;
import com.hexa.myexceptions.DoctorNumberNotFoundException;

public interface IHospitalService {

    Appointment getAppointmentById(int appointmentId);

    List<Appointment> getAppointmentsForPatient(int patientId) throws PatientNumberNotFoundException;

    List<Appointment> getAppointmentsForDoctor(int doctorId) throws DoctorNumberNotFoundException;

    boolean scheduleAppointment(Appointment appointment);

    boolean updateAppointment(Appointment app);
}
