package com.hexa.dao;

import java.sql.*;
import java.util.*;

import com.hexa.entity.*;
import com.hexa.myexceptions.PatientNumberNotFoundException;
import com.hexa.myexceptions.DoctorNumberNotFoundException;
import com.hexa.util.DBConnUtil;

public class HospitalServiceImpl implements IHospitalService {

    private Connection conn;

    public HospitalServiceImpl() {
        try {
            conn = DBConnUtil.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Using JOIN to get appointment details with patient and doctor information
    public Appointment getAppointmentById(int appointmentId) {
        Appointment app = null;
        String query = "SELECT a.appointmentId, a.appointmentDate, a.description, " +
                       "p.patientId, p.firstName AS patientFirstName, p.lastName AS patientLastName, " +
                       "p.dateOfBirth, p.gender, p.contactNumber, p.address, " +
                       "d.doctorId, d.firstName AS doctorFirstName, d.lastName AS doctorLastName, " +
                       "d.specialization, d.contactNumber AS doctorContact " +
                       "FROM Appointment a " +
                       "JOIN Patient p ON a.patientId = p.patientId " +
                       "JOIN Doctor d ON a.doctorId = d.doctorId " +
                       "WHERE a.appointmentId = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, appointmentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Patient p = new Patient(
                    rs.getInt("patientId"),
                    rs.getString("patientFirstName"),
                    rs.getString("patientLastName"),
                    rs.getDate("dateOfBirth").toString(),
                    rs.getString("gender"),
                    rs.getString("contactNumber"),
                    rs.getString("address")
                );
                Doctor d = new Doctor(
                    rs.getInt("doctorId"),
                    rs.getString("doctorFirstName"),
                    rs.getString("doctorLastName"),
                    rs.getString("specialization"),
                    rs.getString("doctorContact")
                );
                app = new Appointment(
                    rs.getInt("appointmentId"),
                    p,
                    d,
                    rs.getDate("appointmentDate").toString(),
                    rs.getString("description")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return app;
    }

    // Using JOIN to get appointments for a patient, with Patient details
    public List<Appointment> getAppointmentsForPatient(int patientId) throws PatientNumberNotFoundException {
        List<Appointment> list = new ArrayList<>();
        String query = "SELECT a.appointmentId, a.appointmentDate, a.description, " +
                       "p.patientId, p.firstName AS patientFirstName, p.lastName AS patientLastName, " +
                       "d.doctorId, d.firstName AS doctorFirstName, d.lastName AS doctorLastName " +
                       "FROM Appointment a " +
                       "JOIN Patient p ON a.patientId = p.patientId " +
                       "JOIN Doctor d ON a.doctorId = d.doctorId " +
                       "WHERE a.patientId = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Patient p = new Patient(
                    rs.getInt("patientId"),
                    rs.getString("patientFirstName"),
                    rs.getString("patientLastName"),
                    "", "", "", ""
                );
                Doctor d = new Doctor(
                    rs.getInt("doctorId"),
                    rs.getString("doctorFirstName"),
                    rs.getString("doctorLastName"),
                    "", ""
                );
                Appointment app = new Appointment(
                    rs.getInt("appointmentId"),
                    p,
                    d,
                    rs.getDate("appointmentDate").toString(),
                    rs.getString("description")
                );
                list.add(app);
            }
            if (list.isEmpty()) {
                throw new PatientNumberNotFoundException("Patient ID " + patientId + " not found in database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Using JOIN to get appointments for a doctor, with Doctor details
    public List<Appointment> getAppointmentsForDoctor(int doctorId) throws DoctorNumberNotFoundException {
        List<Appointment> list = new ArrayList<>();
        String query = "SELECT a.appointmentId, a.appointmentDate, a.description, " +
                       "p.patientId, p.firstName AS patientFirstName, p.lastName AS patientLastName, " +
                       "d.doctorId, d.firstName AS doctorFirstName, d.lastName AS doctorLastName " +
                       "FROM Appointment a " +
                       "JOIN Patient p ON a.patientId = p.patientId " +
                       "JOIN Doctor d ON a.doctorId = d.doctorId " +
                       "WHERE a.doctorId = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, doctorId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Patient p = new Patient(
                    rs.getInt("patientId"),
                    rs.getString("patientFirstName"),
                    rs.getString("patientLastName"),
                    "", "", "", ""
                );
                Doctor d = new Doctor(
                    rs.getInt("doctorId"),
                    rs.getString("doctorFirstName"),
                    rs.getString("doctorLastName"),
                    "", ""
                );
                Appointment app = new Appointment(
                    rs.getInt("appointmentId"),
                    p,
                    d,
                    rs.getDate("appointmentDate").toString(),
                    rs.getString("description")
                );
                list.add(app);
            }
            if (list.isEmpty()) {
                throw new DoctorNumberNotFoundException("Doctor ID " + doctorId + " not found in database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Using a Subquery to insert an appointment, ensuring patient and doctor IDs are valid
    public boolean scheduleAppointment(Appointment appointment) {
        String query = "INSERT INTO Appointment (appointmentId, patientId, doctorId, appointmentDate, description) " +
                       "SELECT ?, ?, ?, ?, ? FROM DUAL " +
                       "WHERE EXISTS (SELECT 1 FROM Patient WHERE patientId = ?) " +
                       "AND EXISTS (SELECT 1 FROM Doctor WHERE doctorId = ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, appointment.getAppointmentId());
            ps.setInt(2, appointment.getPatient().getPatientId());
            ps.setInt(3, appointment.getDoctor().getDoctorId());
            ps.setString(4, appointment.getAppointmentDate());
            ps.setString(5, appointment.getDescription());
            ps.setInt(6, appointment.getPatient().getPatientId());
            ps.setInt(7, appointment.getDoctor().getDoctorId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Using a Subquery to update appointment date if it exists
    public boolean updateAppointment(Appointment app) {
        String query = "UPDATE Appointment SET appointmentDate = ? WHERE appointmentId = ? " +
                       "AND EXISTS (SELECT 1 FROM Appointment WHERE appointmentId = ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, app.getAppointmentDate());
            ps.setInt(2, app.getAppointmentId());
            ps.setInt(3, app.getAppointmentId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
