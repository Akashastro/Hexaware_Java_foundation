package com.hexa.mainmodules;

import java.util.*;
import com.hexa.entity.*;
import com.hexa.dao.*;
import com.hexa.myexceptions.PatientNumberNotFoundException;

public class MainModule {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        IHospitalService service = new HospitalServiceImpl();
        boolean running = true;

        while (running) {
            System.out.println("\n===== HOSPITAL MANAGEMENT MENU =====");
            System.out.println("1. Get Appointment By ID");
            System.out.println("2. Get Appointments for a Patient");
            System.out.println("3. Get Appointments for a Doctor");
            System.out.println("4. Schedule New Appointment");
            System.out.println("5. Update Appointment Date");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); 

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter Appointment ID: ");
                        int appId = sc.nextInt();
                        Appointment app = service.getAppointmentById(appId);
                        System.out.println(app != null ? app : "Appointment not found.");
                        break;

                    case 2:
                        System.out.print("Enter Patient ID: ");
                        int pid = sc.nextInt();
                        List<Appointment> appointments = service.getAppointmentsForPatient(pid);
                        if (appointments.isEmpty()) {
                            System.out.println("No appointments found for patient ID: " + pid);
                        } else {
                            for (Appointment a : appointments) {
                                System.out.println(a);
                            }
                        }
                        break;

                    case 3:
                        System.out.print("Enter Doctor ID: ");
                        int did = sc.nextInt();
                        List<Appointment> doctorApps = service.getAppointmentsForDoctor(did);
                        if (doctorApps.isEmpty()) {
                            System.out.println("No appointments found for doctor ID: " + did);
                        } else {
                            for (Appointment a : doctorApps) {
                                System.out.println(a);
                            }
                        }
                        break;

                    case 4:
                        System.out.print("Enter Appointment ID: ");
                        int newAppId = sc.nextInt();
                        System.out.print("Enter Patient ID: ");
                        int newPid = sc.nextInt();
                        System.out.print("Enter Doctor ID: ");
                        int newDid = sc.nextInt();
                        sc.nextLine(); // consume newline
                        System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
                        String date = sc.nextLine();
                        System.out.print("Enter Description: ");
                        String desc = sc.nextLine();

                        // Create FK object instances
                        Patient patient = new Patient();
                        patient.setPatientId(newPid);
                        Doctor doctor = new Doctor();
                        doctor.setDoctorId(newDid);

                        Appointment newApp = new Appointment(newAppId, patient, doctor, date, desc);
                        boolean scheduled = service.scheduleAppointment(newApp);
                        System.out.println(scheduled ? "Appointment scheduled." : "Failed to schedule.");
                        break;

                    case 5:
                        System.out.print("Enter Appointment ID to update: ");
                        int upId = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter new Appointment Date (YYYY-MM-DD): ");
                        String newDate = sc.nextLine();

                        Appointment upApp = new Appointment();
                        upApp.setAppointmentId(upId);
                        upApp.setAppointmentDate(newDate);
                        boolean updated = service.updateAppointment(upApp);
                        System.out.println(updated ? "Appointment updated." : "Update failed.");
                        break;

                    case 6:
                        running = false;
                        System.out.println("Exiting the application. Goodbye!");
                        break;

                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } catch (PatientNumberNotFoundException ex) {
                System.out.println("Error: " + ex.getMessage());
            } catch (Exception ex) {
                System.out.println("Unexpected error: " + ex.getMessage());
                ex.printStackTrace();
            }
        }

        sc.close();
    }
}
