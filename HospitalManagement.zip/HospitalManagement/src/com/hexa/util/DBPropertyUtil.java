package com.hexa.util;

import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {

    public static String getPropertyString(String fileName) {
        try (InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName)) {
            if (input == null) {
                System.out.println("db.properties file not found in classpath!");
                return null;
            }
            Properties props = new Properties();
            props.load(input);
            return props.getProperty("url") + "?user=" + props.getProperty("username") + "&password=" + props.getProperty("password");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

