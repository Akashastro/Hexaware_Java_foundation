package com.hexa.util;

import java.sql.Connection;

public class DBTest {
    public static void main(String[] args) {
        try {
            Connection conn = DBConnUtil.getConnection();
            if (conn != null) {
                System.out.println(" Database connected successfully!");
                conn.close();
            } else {
                System.out.println(" Failed to connect to the database.");
            }
        } catch (Exception e) {
            System.out.println(" Exception occurred while connecting: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
