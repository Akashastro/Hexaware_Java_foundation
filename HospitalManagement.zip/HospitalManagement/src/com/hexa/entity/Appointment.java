package com.hexa.entity;

public class Appointment {
    private int appointmentId;
    private Patient patient;
    private Doctor doctor;
    private String appointmentDate;
    private String description;

    public Appointment() {}

    public Appointment(int appointmentId, Patient patient, Doctor doctor, String appointmentDate, String description) {
        this.appointmentId = appointmentId;
        this.patient = patient;
        this.doctor = doctor;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String toString() {
        return "Appointment ID: " + appointmentId + "\nDate: " + appointmentDate + "\nDescription: " + description +
               "\nPatient: " + patient.getFirstName() + " " + patient.getLastName() +
               "\nDoctor: " + doctor.getFirstName() + " " + doctor.getLastName() + " (" + doctor.getSpecialization() + ")";
    }
}
