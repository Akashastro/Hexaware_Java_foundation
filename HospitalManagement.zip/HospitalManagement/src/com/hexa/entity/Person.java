package com.hexa.entity;

public class Person {
    private String firstName;
    private String lastName;
    private String gender;
    private String contactNumber;

    public Person() {}

    public Person(String firstName, String lastName, String gender, String contactNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.contactNumber = contactNumber;
    }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }

    public String toString() {
        return "firstName=" + firstName + ", lastName=" + lastName + 
               ", gender=" + gender + ", contactNumber=" + contactNumber;
    }
}

