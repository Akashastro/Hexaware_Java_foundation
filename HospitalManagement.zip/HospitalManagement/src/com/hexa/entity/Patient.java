package com.hexa.entity;

public class Patient extends Person {
    private int patientId;
    private String dateOfBirth;
    private String address;

    public Patient() {}

    public Patient(int patientId, String firstName, String lastName, String dateOfBirth,
                   String gender, String contactNumber, String address) {
        super(firstName, lastName, gender, contactNumber);
        this.patientId = patientId;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
    }

    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public String getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(String dateOfBirth) { this.dateOfBirth = dateOfBirth; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String toString() {
        return "Patient [patientId=" + patientId + ", " + super.toString() +
               ", dateOfBirth=" + dateOfBirth + ", address=" + address + "]";
    }
}
