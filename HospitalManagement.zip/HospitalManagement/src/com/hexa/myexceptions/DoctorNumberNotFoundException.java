package com.hexa.myexceptions;

public class DoctorNumberNotFoundException extends Exception {
    public DoctorNumberNotFoundException(String message) {
        super(message);
    }
}
