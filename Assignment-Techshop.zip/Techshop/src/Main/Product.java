package Main;

public class Product {
    private int productId;
    private String productName;
    private String description;
    private double price;
    private boolean inStock;

    public Product(int productId, String productName, String description, double price, boolean inStock) {
        this.productId = productId;
        this.productName = productName;
        this.description = description;
        this.price = price;
        this.inStock = inStock;
    }

    public void getProductDetails() {
        System.out.println("ID: " + productId);
        System.out.println("Name: " + productName);
        System.out.println("Description: " + description);
        System.out.println("Price: $" + price);
        System.out.println("In Stock: " + inStock);
    }

    public void updateProductInfo(String description, double price) {
        this.description = description;
        this.price = price;
    }

    public boolean isProductInStock() {
        return inStock;
    }

    public void setInStock(boolean stock) {
        this.inStock = stock;
    }
}
