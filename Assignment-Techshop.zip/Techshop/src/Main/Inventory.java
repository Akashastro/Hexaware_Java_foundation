package Main;

public class Inventory {

}
